/*
 * Copyright (c) 2015 Samsung Electronics Co., Ltd. All rights reserved.
 * Redistribution and use in source and binary forms, with or without modification, are permitted provided that
 * the following conditions are met:
 *
 *     * Redistributions of source code must retain the above copyright notice,
 *       this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation and/or
 *       other materials provided with the distribution.
 *     * Neither the name of Samsung Electronics Co., Ltd. nor the names of its contributors may be used to endorse
 *       or promote products derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
 * PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 */

package com.samsung.android.sdk.accessory.example.weather.provider;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class ProviderActivity extends Activity {
    private static final String TAG = "WeatherProvider";
    protected static String temperature[][] = {
            {"18˚C", "15˚C/27˚C"},
            {"19˚C", "16˚C/28˚C"},
            {"30˚C", "22˚C/35˚C"},
            {"21˚C", "18˚C/30˚C"},
            {"22˚C", "19˚C/31˚C"},
            {"23˚C", "20˚C/25˚C"},
            {"20˚C", "17˚C/25˚C"},
            {"29˚C", "28˚C/35˚C"},
    };
    protected static String[] cityArray = {"Amsterdam", "London", "Madrid", "Moscow", "NewYork", "Paris", "Seoul", "Sydney", "Delete City"};

    private WeatherProviderForWidget mWidgetService = null;
    private boolean mIsBound = false;

    private ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            mWidgetService = ((WeatherProviderForWidget.LocalBinder) service).getService();
        }

        @Override
        public void onServiceDisconnected(ComponentName className) {
            mWidgetService = null;
            mIsBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView cityListView = (ListView) findViewById(R.id.listView);
        ArrayAdapter arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_single_choice, cityArray);

        cityListView.setAdapter(arrayAdapter);
        cityListView.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        cityListView.setOnItemClickListener(itemClickListenerOfCityList);

        mIsBound = bindService(new Intent(ProviderActivity.this, WeatherProviderForWidget.class), mConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onDestroy() {
        if (mIsBound && mWidgetService != null) {
            if (mWidgetService.closeConnection() == false) {
                Toast.makeText(getApplicationContext(), R.string.ConnectionAlreadyDisconnected, Toast.LENGTH_LONG).show();
            }


            unbindService(mConnection);
        }

        super.onDestroy();
    }

    public OnItemClickListener itemClickListenerOfCityList = new OnItemClickListener() {
        public void onItemClick(AdapterView<?> parentView, View clickedView, int position, long id) {
            mWidgetService.UpdateNumInt((int) id);
            final JSONObject jsonData = new JSONObject();
            String selected = ((TextView) clickedView).getText().toString();
            Log.d(TAG, "Select: " + selected + "[" + id + "]");
            if (id == 8) {  // Delete City
                try {
                    jsonData.put("delete_city", "delete_city");
                    mWidgetService.sendData(jsonData.toString().getBytes());
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                try {
                    Calendar calendar = new GregorianCalendar();
                    SimpleDateFormat dateFormat = new SimpleDateFormat("hh:mm");
                    String timeStr = dateFormat.format(calendar.getTime());
                    jsonData.put("time_text", timeStr);
                    jsonData.put("city_text", selected);
                    jsonData.put("current_temperature", temperature[(int) id][0]);
                    jsonData.put("day_temperature", temperature[(int) id][1]);
                    mWidgetService.sendData(jsonData.toString().getBytes());
                    Toast.makeText(getApplicationContext(), "Send >>>>> " + selected, Toast.LENGTH_SHORT).show();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
    };
}