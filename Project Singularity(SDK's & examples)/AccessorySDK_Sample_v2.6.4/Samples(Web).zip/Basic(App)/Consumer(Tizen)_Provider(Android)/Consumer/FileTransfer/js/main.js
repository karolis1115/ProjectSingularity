/*    
 * Copyright (c) 2014 Samsung Electronics Co., Ltd.   
 * All rights reserved.   
 *   
 * Redistribution and use in source and binary forms, with or without   
 * modification, are permitted provided that the following conditions are   
 * met:   
 *   
 *     * Redistributions of source code must retain the above copyright   
 *        notice, this list of conditions and the following disclaimer.  
 *     * Redistributions in binary form must reproduce the above  
 *       copyright notice, this list of conditions and the following disclaimer  
 *       in the documentation and/or other materials provided with the  
 *       distribution.  
 *     * Neither the name of Samsung Electronics Co., Ltd. nor the names of its  
 *       contributors may be used to endorse or promote products derived from  
 *       this software without specific prior written permission.  
 *  
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS  
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT  
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR  
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT  
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,  
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT  
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,  
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY  
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT  
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE  
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

var gTransferId = 0;
var progressBar = document.getElementById("file-progress");
var ratio = document.getElementById("file-ratio");

/* Alert message with toast popup of TAU */
function toastAlert(msg) {
	var toastMsg = document.getElementById("popupToastMsg");
	toastMsg.innerHTML = msg;
	tau.openPopup('#popupToast');
	console.log(msg);
}

function showMain(message) {
	tau.changePage('#main');
	if (message != undefined) {
		toastAlert(message);
	}
	gTransferId = 0;
}

var ftSuccessCb = {
	onsuccess : function () {
		toastAlert('Succeed to connect');
		updateContents();
	},
	onsendprogress : function (id, progress) {
		console.log('onprogress id : ' + id + ' progress : ' + progress);
		progressBar.value = progress;
		ratio.innerHTML = progress + "%";
	},
	onsendcomplete : function (id, localPath) {
		progressBar.value = 100;
		ratio.innerHTML = "100%";
		showMain('send Completed!! id : ' + id + ' localPath :' + localPath);
	},
	onsenderror : function (errCode, id) {
		showMain('Failed to send File. id : ' + id + ' errorCode :' + errCode);
	}
};

function clearList(reconnect) {
	console.log('clear List');
	var context = document.getElementsByClassName("ui-listview");
	context[0].innerHTML="";
	if (reconnect) {
		var context = document.getElementsByClassName("ui-listview"),
		 element = document.createElement("li");
		 element.innerHTML = '<a href="#" onclick="reconnect();">Connect</a>';
		 window.tau.util.DOM.appendNodes(context[0], element);
	} else {
		var context = document.getElementsByClassName("ui-listview"),
		 element = document.createElement("li");
		 element.innerHTML = '<li>BT Disconnected. Connection waiting...</li>';
		 window.tau.util.DOM.appendNodes(context[0], element);
	}
	var snaplistEl = document.getElementsByClassName('ui-snap-listview')[0];
	if (snaplistEl) {
		var snaplistWidget = tau.widget.SnapListview(snaplistEl);
		snaplistWidget.refresh();
	}
}

function reconnect() {
	var context = document.getElementsByClassName("ui-listview");
	context[0].innerHTML="";
	sapFindPeer(function(){
		console.log('Succeed to find peer');
		ftInit(ftSuccessCb, function(err) {
			toastAlert('Failed to get File Transfer');
			clearList(true);
		});
	}, function(err){
		toastAlert('Failed to reconnect to service');
		clearList(true);
	});

}

function updateContents() {
	try {
		tizen.content.find(function(contents) {
			var context = document.getElementsByClassName("ui-listview");
			context[0].innerHTML="";
			if (contents.length > 0) {
				for(var i = 0; i < contents.length ; i++) {
					console.log('name : ' + contents[i].title + ' URI : ' + contents[i].contentURI);
					var nameStr = (contents[i].title.length > 15) ? (contents[i].title.substring(0, 11) + '...') : contents[i].title;
					var context = document.getElementsByClassName("ui-listview"),
					 element = document.createElement("li");
					 element.innerHTML = '<a onclick="sendFile(\'' + contents[i].contentURI + '\');">' + nameStr
		                + '</a>';
					 window.tau.util.DOM.appendNodes(context[0], element);
				}
				var context = document.getElementsByClassName("ui-listview"),
				 element = document.createElement("li");
				 element.innerHTML = '<a onclick="updateContents();">Update contents...</a>';
				 window.tau.util.DOM.appendNodes(context[0], element);
			} else {
				var context = document.getElementsByClassName("ui-listview"),
				 element = document.createElement("li");
				 element.innerHTML = 'a onclick="updateContents();">No items. Update contents</a>';
				 window.tau.util.DOM.appendNodes(context[0], element);
			}
			var snaplistEl = document.getElementsByClassName('ui-snap-listview')[0];
			if (snaplistEl) {
				var snaplistWidget = tau.widget.SnapListview(snaplistEl);
				snaplistWidget.refresh();
			}
		}, function(err) {
			console.log('Failed to find contents');
		});
	} catch(err) {
		console.log('content.find exception <' + err.name + '> : ' + err.message);
	}
}

function initialize() {
	var sapinitsuccesscb = {
			onsuccess : function () {
				console.log('Succeed to connect');
				ftInit(ftSuccessCb, function(err) {
					toastAlert('Failed to get File Transfer');
				});
			},
			ondevicestatus : function(status) {
				if (status == "DETACHED") {
					console.log('Detached remote peer device');
					clearList();
				} else if (status == "ATTACHED") {
					console.log('Attached remote peer device');
					reconnect();
				}
			}
	};

	sapInit(sapinitsuccesscb, function(err) {
		toastAlert('Failed to connect to service');
	});
}

function cancelFile() {
	ftCancel(gTransferId,function() {
		console.log('Succeed to cancel file');
		showMain();
	}, function(err) {
	    console.log('Failed to cancel File');
	    showMain();
	});
}

function sendFile(path) {
	ftSend(path, function(id) {
		console.log('Succeed to send file');
		gTransferId = id;
		tau.changePage('#sendPage');
		progressBar.value = 0;
		ratio.innerHTML = "0%";
	}, function(err) {
		showMain('Failed to send File');
	});
}

(function() {
	// tau progress bar implementation
	var sendPage = document.getElementById('sendPage');
	sendPage.addEventListener('pagehide', function() {
	});

	window.addEventListener('tizenhwkey', function(e) {
		/* For the flick down gesture */
		if (e.keyName == "back")
		{
			var page = document.getElementsByClassName('ui-page-active')[0],
				pageid = page ? page.id : " ";
			if (pageid === "main") {
				/* When a user flicks down, the application exits */
				tizen.application.getCurrentApplication().exit();
			}
			else {
				cancelFile();
				window.history.back();
			}
		}
	});
	
	window.addEventListener('load', function(ev) {
		var context = document.getElementsByClassName("ui-listview"),
		 element = document.createElement("li");
		 element.innerHTML = '<a href="#" onclick="initialize();">Connect</a>';
		 window.tau.util.DOM.appendNodes(context[0], element);
	});
}());
(function(tau) {
	var toastPopup = document.getElementById('popupToast');
	toastPopup.addEventListener('popupshow', function(ev){
		setTimeout(function(){tau.closePopup();}, 3000);
	}, false);
})(window.tau);
